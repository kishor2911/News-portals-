﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace News_Portal
{
    public partial class Home : System.Web.UI.Page
    {
        private readonly string connectionString = "Data Source=LAPTOP-VIEHC5I6\\SQLEXPRESS01;Initial Catalog=NewsPortalDB;Integrated Security=True;";

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadArticles();
            }
        }

        private void LoadArticles()
        {
            string query = "SELECT NewsID, Title, Category, Description, ImagePath FROM News";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open(); // Ensure the connection is opened
                    SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    articleList.Controls.Clear(); // Clear previous content

                    if (dt.Rows.Count == 0)
                    {
                        articleList.Controls.Add(new LiteralControl("<p style='color:red;'>No articles found.</p>"));
                        return;
                    }

                    foreach (DataRow row in dt.Rows)
                    {
                        string newsId = row["NewsID"].ToString();
                        string title = row["Title"].ToString();
                        string category = row["Category"].ToString();
                        string description = row["Description"].ToString();
                        string imagePath = row["ImagePath"].ToString();

                        string imageUrl = "~/Uploads/default.jpg"; // Default image
                        if (!string.IsNullOrWhiteSpace(imagePath))
                        {
                            string fullPhysicalPath = Server.MapPath("~/Uploads/" + Path.GetFileName(imagePath));
                            if (File.Exists(fullPhysicalPath))
                            {
                                imageUrl = "~/Uploads/" + Path.GetFileName(imagePath);
                            }
                        }

                        Panel articlePanel = new Panel();
                        articlePanel.CssClass = "col-md-12 article-card";

                        Image img = new Image
                        {
                            ImageUrl = ResolveUrl(imageUrl),
                            CssClass = "article-image",
                            AlternateText = title
                        };

                        Literal lblTitle = new Literal { Text = $"<h3 class='article-title'>{title}</h3>" };
                        Literal lblCategory = new Literal { Text = $"<p class='article-category'><b>Category:</b> {category}</p>" };
                        string shortDescription = description.Length > 150 ? description.Substring(0, 150) + "..." : description;
                        Literal lblDescription = new Literal { Text = $"<p class='article-description'>{shortDescription}</p>" };

                        // Using HyperLink instead of LinkButton
                        HyperLink btnReadMore = new HyperLink
                        {
                            Text = "Read More",
                            CssClass = "read-more-btn",
                            NavigateUrl = "~/ReadArticle.aspx?id=" + newsId // Redirects to the article page
                        };

                        articlePanel.Controls.Add(img);
                        articlePanel.Controls.Add(lblTitle);
                        articlePanel.Controls.Add(lblCategory);
                        articlePanel.Controls.Add(lblDescription);
                        articlePanel.Controls.Add(btnReadMore);

                        articleList.Controls.Add(articlePanel);
                    }
                }
                catch (Exception ex)
                {
                    ShowAlert("Error: " + ex.Message);
                }
                finally
                {
                    conn.Close(); // Ensure connection is closed
                }
            }
        }

        private void ShowAlert(string message)
        {
            ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('" + message + "');", true);
        }
    }
}
