﻿

using System;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Web.UI;

namespace News_Portal.Main_admin
{
    public partial class ReadArticle : System.Web.UI.Page
    {
        // Updated connection string without the 'Trust Server Certificate' option
        string connectionString = "Data Source=LAPTOP-VIEHC5I6\\SQLEXPRESS01;Initial Catalog=NewsPortalDB;Integrated Security=True";

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadArticle();
            }
        }

        private void LoadArticle()
        {
            string articleId = Request.QueryString["id"];

            if (string.IsNullOrEmpty(articleId))
            {
                litError.Text = "<p style='color:red;'>Invalid Article ID.</p>";
                return;
            }

            string query = "SELECT Title, Category, Description, ImagePath FROM News WHERE NewsID = @NewsID";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.Add("@NewsID", SqlDbType.Int).Value = int.Parse(articleId);
                    SqlDataReader reader = cmd.ExecuteReader();

                    if (reader.Read())
                    {
                        litTitle.Text = reader["Title"].ToString();
                        litCategory.Text = reader["Category"].ToString();
                        litDescription.Text = reader["Description"].ToString();

                        string imagePath = reader["ImagePath"].ToString();
                        string imageUrl = "~/Uploads/default.jpg"; // Default image

                        if (!string.IsNullOrWhiteSpace(imagePath))
                        {
                            string fullPhysicalPath = Server.MapPath("~/Uploads/" + Path.GetFileName(imagePath));
                            if (File.Exists(fullPhysicalPath))
                            {
                                imageUrl = "~/Uploads/" + Path.GetFileName(imagePath);
                            }
                        }

                        imgArticle.Src = imageUrl;
                    }
                    else
                    {
                        litError.Text = "<p style='color:red;'>Article not found.</p>";
                    }
                }
            }
        }
    }
}
