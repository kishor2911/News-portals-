﻿using System;
using System.Data.SqlClient;
using System.IO;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;

namespace News_Portal
{
    public partial class NewsCategory : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string category = Request.QueryString["category"];

                if (string.IsNullOrEmpty(category))
                {
                    litNoNews.Text = "<p>No category selected.</p>";
                    rptNews.Visible = false;
                    return;
                }

                litCategoryTitle.Text = $"<h2>News for Category: {category}</h2>";
                LoadNewsByCategory(category);
            }
        }

        private void LoadNewsByCategory(string category)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["NewsPortalDB"].ConnectionString;
            string query = "SELECT NewsID, Title, ISNULL(Description, 'No description available') AS Description, ISNULL(ImagePath, '') AS ImagePath FROM News WHERE Category = @Category ORDER BY CreatedAt DESC";

            using (SqlConnection conn = new SqlConnection(connectionString))
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@Category", category);

                try
                {
                    conn.Open();
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.HasRows)
                        {
                            rptNews.DataSource = reader;
                            rptNews.DataBind();
                            rptNews.Visible = true;
                            litNoNews.Visible = false;
                        }
                        else
                        {
                            rptNews.Visible = false;
                            litNoNews.Text = "<p>No news available in this category.</p>";
                            litNoNews.Visible = true;
                        }
                    }
                }
                catch (Exception ex)
                {
                    litNoNews.Text = $"<p style='color:red;'>Error: {ex.Message}</p>";
                    litNoNews.Visible = true;
                    rptNews.Visible = false;
                }
            }
        }

   
        public string GetImageUrl(object imagePath)
        {
      
            string imageUrl = "~/Uploads/default.jpg"; 

            if (!string.IsNullOrWhiteSpace(imagePath?.ToString()))
            {
                string fileName = Path.GetFileName(imagePath.ToString());

                
                string relativeImagePath = "~/Uploads/" + fileName;

                string fullPhysicalPath = Server.MapPath(relativeImagePath); 
                if (File.Exists(fullPhysicalPath))
                {
                    imageUrl = relativeImagePath; 
                }
                else
                {
                    imageUrl = "~/Uploads/default.jpg"; 
                }
            }

            
            return imageUrl;
        }

     
        public string GetImagePathText(object imagePath)
        {
           
            return imagePath?.ToString() ?? "No image path available";
        }
    }
}
