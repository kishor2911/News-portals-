﻿using System;
using System.Configuration;
using System.Data.SqlClient;
using BCrypt.Net;

namespace News_Portal
{
    public partial class admin : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            lblErrorMessage.Text = "";
        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text.Trim();
            string password = txtPassword.Text.Trim();

            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            {
                lblErrorMessage.Text = "Username and Password are required!";
                return;
            }

            string connStr = ConfigurationManager.ConnectionStrings["NewsPortalDB"].ConnectionString;

            string query = "SELECT Password FROM Admins WHERE Username = @Username";

            using (SqlConnection con = new SqlConnection(connStr))
            {
                try
                {
                    con.Open();

                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@Username", username);

                        var storedHashedPassword = cmd.ExecuteScalar()?.ToString();

                        if (storedHashedPassword != null && BCrypt.Net.BCrypt.Verify(password, storedHashedPassword))
                        {
                            Response.Redirect("~/Main_admin/Dashboard.aspx");
                        }
                        else
                        {
                            lblErrorMessage.Text = "Invalid Username or Password.";
                        }
                    }
                }
                catch (Exception ex)
                {
                    lblErrorMessage.Text = "An error occurred: " + ex.Message;
                }
            }
        }
    }
}
