﻿using System;
using System.Data.SqlClient;
using System.Web.UI;

namespace News_Portal.Main_admin
{
    public partial class UpdateArticle : System.Web.UI.Page
    {
        private readonly string connectionString = "Data Source=LAPTOP-VIEHC5I6\\SQLEXPRESS01;Initial Catalog=NewsPortalDB;Integrated Security=True";

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string articleId = Request.QueryString["id"];
                if (string.IsNullOrEmpty(articleId))
                {
                    ShowError("No article selected to update.");
                    return;
                }

                LoadArticleDetails(articleId);
            }
        }

        private void LoadArticleDetails(string articleId)
        {
            try
            {
                string query = "SELECT Title, Category, Description, ImagePath FROM News WHERE NewsID = @NewsID";
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@NewsID", articleId);

                    conn.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    if (reader.HasRows)
                    {
                        reader.Read();
                        txtTitle.Text = reader["Title"].ToString();
                        txtCategory.Text = reader["Category"].ToString();
                        txtDescription.Text = reader["Description"].ToString();
                        // Optionally, display image path or load an image preview if needed.
                    }
                    else
                    {
                        ShowError("Article not found.");
                    }
                }
            }
            catch (Exception ex)
            {
                ShowError("Error loading article: " + ex.Message);
            }
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            string articleId = Request.QueryString["id"];
            if (string.IsNullOrEmpty(articleId))
            {
                ShowError("No article selected to update.");
                return;
            }

            try
            {
                string query = "UPDATE News SET Title = @Title, Category = @Category, Description = @Description WHERE NewsID = @NewsID";
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@Title", txtTitle.Text);
                    cmd.Parameters.AddWithValue("@Category", txtCategory.Text);
                    cmd.Parameters.AddWithValue("@Description", txtDescription.Text);
                    cmd.Parameters.AddWithValue("@NewsID", articleId);

                    conn.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();
                    if (rowsAffected > 0)
                    {
                        ShowSuccess("Article updated successfully.");
                    }
                    else
                    {
                        ShowError("Error: Article not found.");
                    }
                }
            }
            catch (Exception ex)
            {
                ShowError("Error updating article: " + ex.Message);
            }
        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            string articleId = Request.QueryString["id"];
            if (string.IsNullOrEmpty(articleId))
            {
                ShowError("No article selected to delete.");
                return;
            }

            try
            {
                string query = "DELETE FROM News WHERE NewsID = @NewsID";
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@NewsID", articleId);

                    conn.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();
                    if (rowsAffected > 0)
                    {
                        // Optionally, show a success message before redirecting
                        ShowSuccess("Article deleted successfully.");
                        // Redirect to the Articles page (or any other appropriate page)
                        Response.Redirect("Articles.aspx");
                    }
                    else
                    {
                        ShowError("Error: Article not found or already deleted.");
                    }
                }
            }
            catch (Exception ex)
            {
                ShowError("Error deleting article: " + ex.Message);
            }
        }

        private void ShowError(string message)
        {
            lblError.Text = message;
            lblError.Visible = true;
            lblSuccess.Visible = false;
        }

        private void ShowSuccess(string message)
        {
            lblSuccess.Text = message;
            lblSuccess.Visible = true;
            lblError.Visible = false;
        }
    }
}
