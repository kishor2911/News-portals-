﻿using System;
using System.Data.SqlClient;
using System.Web.UI;
using BCrypt.Net;  // Import the BCrypt library for hashing

namespace News_Portal.Main_admin
{
    public partial class ChangePassword : System.Web.UI.Page
    {
        string connectionString = "Data Source=LAPTOP-VIEHC5I6\\SQLEXPRESS01;Initial Catalog=NewsPortalDB;Integrated Security=True";

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack) { }
        }

        protected void SubmitButton_Click(object sender, EventArgs e)
        {
            string username = Username.Value.Trim();
            string oldPassword = OldPassword.Value.Trim();
            string newPassword = NewPassword.Value.Trim();
            string confirmNewPassword = ConfirmNewPassword.Value.Trim();

            if (newPassword != confirmNewPassword)
            {
                ErrorCommon.InnerText = "New passwords do not match.";
                return;
            }

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                // Step 1: Get the stored hashed password from the Admins table
                string query = "SELECT Password FROM Admins WHERE Username = @Username";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Username", username);
                    var result = cmd.ExecuteScalar();

                    if (result != null)
                    {
                        string storedHashedPassword = result.ToString();

                        // Step 2: Verify the old password
                        if (BCrypt.Net.BCrypt.Verify(oldPassword, storedHashedPassword))
                        {
                            // Step 3: Hash the new password
                            string hashedNewPassword = BCrypt.Net.BCrypt.HashPassword(newPassword);

                            // Step 4: Update the new hashed password in the database
                            string updateQuery = "UPDATE Admins SET Password = @NewPassword WHERE Username = @Username";
                            using (SqlCommand updateCmd = new SqlCommand(updateQuery, conn))
                            {
                                updateCmd.Parameters.AddWithValue("@NewPassword", hashedNewPassword);
                                updateCmd.Parameters.AddWithValue("@Username", username);

                                int rowsAffected = updateCmd.ExecuteNonQuery();
                                if (rowsAffected > 0)
                                {
                                    Response.Write("<script>alert('Password updated successfully!');</script>");
                                }
                                else
                                {
                                    ErrorCommon.InnerText = "Error updating the password. Please try again later.";
                                }
                            }
                        }
                        else
                        {
                            ErrorCommon.InnerText = "Incorrect old password.";
                        }
                    }
                    else
                    {
                        ErrorCommon.InnerText = "Username not found.";
                    }
                }
            }
        }
    }
}
