﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace News_Portal.Main_admin
{
    public partial class Articles : System.Web.UI.Page
    {
        // Update the connection string as needed.
        private readonly string connectionString = "Data Source=LAPTOP-VIEHC5I6\\SQLEXPRESS01;Initial Catalog=NewsPortalDB;Integrated Security=True";

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadArticles(); // Load articles on first page load.
            }
        }

        private void LoadArticles()
        {
            string query = "SELECT NewsID, Title, Category, Description, ImagePath FROM News";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
                DataTable dt = new DataTable();
                adapter.Fill(dt);

                // Clear previous content.
                articleList.Controls.Clear();

                if (dt.Rows.Count == 0)
                {
                    articleList.Controls.Add(new LiteralControl("<p style='color:red;'>No articles found.</p>"));
                    return;
                }

                // Dynamically create article cards.
                foreach (DataRow row in dt.Rows)
                {
                    string newsId = row["NewsID"].ToString();
                    string title = row["Title"].ToString();
                    string category = row["Category"].ToString();
                    string description = row["Description"].ToString();
                    string imagePath = row["ImagePath"].ToString();

                    // Set a default image if none exists.
                    string imageUrl = "~/Uploads/default.jpg";
                    if (!string.IsNullOrWhiteSpace(imagePath))
                    {
                        string fullPhysicalPath = Server.MapPath("~/Uploads/" + Path.GetFileName(imagePath));
                        if (File.Exists(fullPhysicalPath))
                        {
                            imageUrl = "~/Uploads/" + Path.GetFileName(imagePath);
                        }
                    }

                    // Create a Panel for the article card.
                    Panel articlePanel = new Panel { CssClass = "col-md-4 article-card" };

                    // Article image.
                    Image img = new Image
                    {
                        ImageUrl = imageUrl,
                        CssClass = "article-image",
                        AlternateText = title
                    };

                    // Title, category, and short description.
                    Literal lblTitle = new Literal { Text = $"<h3>{title}</h3>" };
                    Literal lblCategory = new Literal { Text = $"<p><b>Category:</b> {category}</p>" };
                    string shortDescription = description.Length > 100 ? description.Substring(0, 100) + "..." : description;
                    Literal lblDescription = new Literal { Text = $"<p>{shortDescription}</p>" };

                    // (Optional) HiddenField storing the article ID.
                    HiddenField hfNewsID = new HiddenField
                    {
                        ID = "hfNewsID_" + newsId,
                        Value = newsId
                    };

                    // Update hyperlink.
                    HyperLink btnUpdate = new HyperLink
                    {
                        Text = "Update // Delete",
                        CssClass = "btn btn-warning",
                        NavigateUrl = "~/Main_admin/UpdateArticle.aspx?id=" + newsId
                    };

                    // Add controls to the article panel.
                    articlePanel.Controls.Add(img);
                    articlePanel.Controls.Add(new LiteralControl("<br/>"));
                    articlePanel.Controls.Add(lblTitle);
                    articlePanel.Controls.Add(lblCategory);
                    articlePanel.Controls.Add(lblDescription);
                    articlePanel.Controls.Add(new LiteralControl("<br/>"));
                    articlePanel.Controls.Add(hfNewsID);  // Optional hidden field.
                    articlePanel.Controls.Add(btnUpdate);

                    // Add the article panel to the article list placeholder.
                    articleList.Controls.Add(articlePanel);
                }
            }
        }

        private void ShowAlert(string message)
        {
            // Display an alert using JavaScript via ScriptManager.
            ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", $"alert('{message}');", true);
        }
    }
}
