﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.IO;

namespace News_Portal.Main_admin
{
    public partial class Dashboard : System.Web.UI.Page
    {
        // Replace with a valid connection string
        private string connectionString = "Data Source=LAPTOP-VIEHC5I6\\SQLEXPRESS01;Initial Catalog=NewsPortalDB;Integrated Security=True";

        protected void Page_Load(object sender, EventArgs e)
        {
        }

        protected void btnCreateNews_Click(object sender, EventArgs e)
        {
            string title = txtNewsTitle.Text.Trim();
            string category = ddlNewsCategory.SelectedValue;
            string description = txtNewsDescription.Text.Trim();
            string imagePath = "";

            if (fileNewsImage.HasFile)
            {
                // Get the folder path to save the image
                string folderPath = Server.MapPath("~/Uploads/");

                // Ensure the directory exists
                if (!Directory.Exists(folderPath))
                {
                    // Create the directory if it doesn't exist
                    Directory.CreateDirectory(folderPath);
                }

                // Combine the folder path with the uploaded file name
                imagePath = folderPath + fileNewsImage.FileName;

                try
                {
                    // Save the uploaded file to the specified path
                    fileNewsImage.SaveAs(imagePath);
                }
                catch (Exception ex)
                {
                    lblError.ForeColor = System.Drawing.Color.Red;
                    lblError.Text = "Error uploading the file: " + ex.Message;
                    lblError.Visible = true;
                    return; // Exit the method if file upload fails
                }
            }

            string query = "INSERT INTO News (Title, Category, Description, ImagePath, CreatedAt) " +
                           "VALUES (@Title, @Category, @Description, @ImagePath, GETDATE())";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@Title", title);
                        cmd.Parameters.AddWithValue("@Category", category);
                        cmd.Parameters.AddWithValue("@Description", description);
                        cmd.Parameters.AddWithValue("@ImagePath", imagePath);

                        cmd.ExecuteNonQuery();
                    }

                    // Clear the form fields after successful insertion
                    txtNewsTitle.Text = "";
                    ddlNewsCategory.SelectedIndex = 0;
                    txtNewsDescription.Text = "";
                    lblError.Visible = false;

                    // Show success message
                    lblError.ForeColor = System.Drawing.Color.Green;
                    lblError.Text = "News Upload  successfully";
                    lblError.Visible = true;
                }
                catch (Exception ex)
                {
                    // Handle any errors that may have occurred
                    lblError.ForeColor = System.Drawing.Color.Red;
                    lblError.Text = "Error: " + ex.Message;
                    lblError.Visible = true;
                }
            }
        }
    }
}
