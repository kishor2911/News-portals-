﻿using System;
using System.Web;
using System.Web.UI;

namespace News_Portal.Main_admin
{
    public partial class Logout : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // Remove user session
            Session.Clear();
            Session.Abandon();

            // Remove authentication cookies if any
            if (Request.Cookies["AuthCookie"] != null)
            {
                HttpCookie authCookie = new HttpCookie("AuthCookie");
                authCookie.Expires = DateTime.Now.AddDays(-1);
                Response.Cookies.Add(authCookie);
            }

            // Redirect to home page (change "Home.aspx" to your actual home page URL)
            Response.Redirect("~/Home.aspx");
        }
    }
}
