# NewsPortalDB Database Setup

## Introduction
This document provides instructions for setting up the `NewsPortalDB` database, including creating necessary tables and running select queries.

## Database Creation
To create the `NewsPortalDB` database, execute the following SQL command:
```sql
CREATE DATABASE NewsPortalDB;
GO
USE NewsPortalDB;
```

## Table Creation
The following SQL statements create the required tables for the `NewsPortalDB` database.

### Admins Table
```sql
CREATE TABLE [dbo].[Admins] (
    [ID]          INT            IDENTITY (1, 1) NOT NULL,
    [Username]    NVARCHAR (50)  NOT NULL,
    [Email]       NVARCHAR (100) NOT NULL,
    [Password]    NVARCHAR (255) NOT NULL,
    [ResetToken]  NVARCHAR (255) NULL,
    [TokenExpiry] DATETIME       NULL,
    PRIMARY KEY CLUSTERED ([ID] ASC),
    UNIQUE NONCLUSTERED ([Username] ASC),
    UNIQUE NONCLUSTERED ([Email] ASC)
);
```

### ContactForm Table
```sql
CREATE TABLE [dbo].[ContactForm] (
    [ContactID]     INT           IDENTITY (1, 1) NOT NULL,
    [Name]          VARCHAR (255) NOT NULL,
    [Email]         VARCHAR (255) NOT NULL,
    [Subject]       VARCHAR (255) NOT NULL,
    [Message]       TEXT          NOT NULL,
    [SubmittedDate] DATETIME      DEFAULT (getdate()) NULL,
    PRIMARY KEY CLUSTERED ([ContactID] ASC)
);
```

### News Table
```sql
CREATE TABLE [dbo].[News] (
    [NewsID]      INT            IDENTITY (1, 1) NOT NULL,
    [Title]       NVARCHAR (255) NOT NULL,
    [Category]    NVARCHAR (50)  NOT NULL,
    [Description] TEXT           NOT NULL,
    [ImagePath]   NVARCHAR (255) NOT NULL,
    [CreatedAt]   DATETIME       DEFAULT (getdate()) NULL,
    PRIMARY KEY CLUSTERED ([NewsID] ASC)
);
```

## Sample Queries
To retrieve data from the tables, use the following SQL `SELECT` queries:

### Retrieve all Admins
```sql
SELECT * FROM [dbo].[Admins];
```

### Retrieve all Contact Form Submissions
```sql
SELECT * FROM [dbo].[ContactForm];
```

### Retrieve all News Articles
```sql
SELECT * FROM [dbo].[News];
```

## Notes
- Ensure that SQL Server is properly installed and running before executing the commands.
- Adjust data types or constraints as needed based on your project requirements.
- The database should be backed up regularly to prevent data loss.

## Author
Kishor Goraniya

## License
This project is open-source and can be modified as needed.

